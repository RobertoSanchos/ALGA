## <p align="center">Szorzattá alakítás II.</p>
#### <u>Azonosságok

$ (a+b)^2 = a^2+2ab+b^2 $
$ (a-b)^2 = a^2-2ab+b^2 $
$ (a-b)(a+b) = a^2-b^2 $ 

#### <u>1. feladat
#### $ {2x-4} =$ 
<br>
<br>

#### 2. feladat
#### $ {3y^2-12} =$ 
<br>
<br>

#### 3. feladat
#### $ {z^3+3z^2} =$ 
<br>
<br>

#### 4. feladat
#### $ {u^3+3u^2-u} =$ 
<br>
<br>

#### 5. feladat
#### $ {14x-2x^2-24} =$ 
<br>
<br>


#### 6. feladat
#### $ {(a-1)^2} =$ 
<br>
<br>

#### 7. feladat
#### $ {(x+2y)^2} =$ 
<br>
<br>

#### 8. feladat
#### $ {(-b-3d)^2} =$ 
<br>
<br>

#### 9. feladat
#### $ {(u-5)(u+5)} =$ 
<br>
<br>

#### 10. feladat
#### $ {(v+{1 \over \sqrt v})} {(v+{1 \over \sqrt v})}=$ 
