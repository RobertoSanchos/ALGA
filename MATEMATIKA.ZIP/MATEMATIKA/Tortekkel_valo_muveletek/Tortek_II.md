## <p align="center">Törtekkel való műveletek II.</p>

#### <u>1. feladat
#### $ ({1 \over 3} - {2 \over 5}):{3 \over 7} =$

#### 2. feladat
#### $ {1 \over 3} - {2 \over 5}:{3 \over 7} =$

#### 3. feladat
#### $ {1 \over 2} · (3 +{ 7 \over 6}) =$

#### 4. feladat
#### $ {1 \over 2} · 3 +{ 7 \over 6} =$

#### 5. feladat
#### $ {1 \over a}  +{ 1 \over b} =$

#### 6. feladat
#### $ {1 \over a+1}  +{ 1 \over a-1} =$

#### 7. feladat
#### $ {1 \over a^2b}  +{ 1 \over b^2} =$

#### 8. feladat
#### $ {1 \over a+1}  +{ 1 \over(a+1)^2} =$

#### 9. feladat
#### $ {a+2 \over a^2-a}  +{ 1 \over a} =$

#### 10. feladat
#### $ {1 \over a+1} + 1 =$

#### 11. feladat
#### $ a - {1 \over a+1} =$

#### 12. feladat
#### $ {b+1 \over a+1} : (b+2) =$

#### 13. feladat
#### $ {1 \over a+1} : a-2 =$

#### 14. feladat
#### $ 3 · {1 \over a+1} - {2 \over 3} =$

#### 15. feladat
#### $ {5 \over 2x} - {1 \over x} + {2x \over 5} =$

#### 16. feladat
#### $ {6a+7 \over a^2+a} - {5 \over a+1} =$

#### 17. feladat
#### $ {x+1 \over x+2} - {2x-3 \over x-2} + {x^2 +2x+4\over x^2-4} =$
