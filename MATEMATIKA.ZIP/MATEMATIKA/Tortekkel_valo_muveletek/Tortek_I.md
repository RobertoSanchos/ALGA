## <p align="center">Törtekkel való műveletek I.</p>

#### <u>1. feladat
#### $ {1 \over 2} + {2 \over 3} =$ 

#### 2. feladat
#### $ {1 \over 2} - {3 \over 4} =$ 

#### 3. feladat
#### $ {7 \over 32} - {9 \over 64} =$ 

#### 4. feladat
#### $ {5 \over 12} - {7 \over 16} =$ 

#### 5. feladat
#### $ {1 \over 2} + {2 \over 3} =$ 

#### 6. feladat
#### $ {5 \over6} - 2 =$ 

#### 7. feladat
#### $ {2 \over -3} - {-3 \over 2} + {-7 \over -5} =$ 

#### 8. feladat
#### $ {1 \over 2} - ({3 \over 5} + {7 \over -3}) =$

#### 9. feladat
#### $ 3 - ({-3 \over 4} - {1 \over -6})+ {-2 \over 8} =$

#### <u>10. feladat
#### $ {3 \over 2} · {5 \over 4} =$

#### 11. feladat
#### $ {3 \over 2} · {-4 \over 5} =$

#### 12. feladat
#### $ {3 \over 2} · 7 =$

#### 13. feladat
#### $ {3 \over 2} : {5 \over 4} =$

#### 14. feladat
#### $ {3 \over 2} : 5 =$

#### 15. feladat
#### $ {{16 \over 3} \over 5} =$

#### 16. feladat
#### $ {16 \over {3 \over 5}} =$

#### 17. feladat
#### $ {{16 \over 3} \over {5 \over 2}} =$

#### 18. feladat
#### $ {{16 \over 3} \over 1+{5 \over 2}} =$

#### 19. feladat
#### $ {x^2-25 \over x^2-10x+25} =$