# Azonosságok
### $ \sqrt[n] a *\sqrt[n] b = \sqrt[n] {a*b} $
### $ {\sqrt[n]{ a \over b}} = {{\sqrt[n] a} \over {\sqrt[n] b}}  $

