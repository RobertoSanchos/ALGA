# FORMÁZÁSOK


# This is **Bold**, *Italic*, _*Bold+ italic*_, ~~crossed~~, <mark>highlited</mark>, X<sup>2</sup>,H<sub>2</sub>O, 

# PROGRAMKÓDOK

```python
print("asd")
asd = 10;
for i in range(1, 10):
    print(i)
    if i > 10:
        break;
```

# LINKEK
## [this is a link](https://google.com)

<https://google.com>

![Google Logo](g_logo.png)

# IDÉZETEK

> megjegyzés
sdadsadsa

>>asd

>>>asdsad

# VONAL

asdi
***

# LISTÁK

1. Lista elem 1
2. Lista elem 2

* Lista elem 1
* Lista elem 2
    * Lista elem 3

- Lista elem 1
- Lista elem 2

# TÁBLÁK

| OSZLOP_1 | OSZLOP_2 | OSZLOP_3 |
| -: | :-:| :- |
|1.SOR | 1.SOR | 1.SOR |
|2.SOR | 2.SOR | 2.SOR |
|3.SOR | 3.SOR | 3.SOR |

# KÉPLETEK
$\sqrt{3+x}=-2$
$x_{1,2} =$