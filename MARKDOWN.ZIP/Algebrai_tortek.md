# Egyszerűsítés, szorzás, osztás

## 1.feladat
### ${{x^2-25x^2} \over {x^2-10x+25}} = {{(x-5)(x+5)} \over {x-5}^2} = {{x+5} \over {x-5}} \sqrt 5$
### $\sqrt 5$
### $ {{16-x^2} \over {16x-8x^2+x^3}} *{{4x^3-x^4} \over {x^4+8x^3+16x^2}}= {{(x-4)(x+4)} \over x{(x^2-8x+16)}}* {{x^3(4-x)} \over {x^2(x^2+8x+16)}} =  {{(x-4)(x+4)} \over x{(4-x)^2}}* {{x^3(4-x)} \over {x^2(x+4)^2}} = {{(x+4)} \over x{(4-x)}}* {{x(4-x)} \over {(x+4)^2}} = $


