# Törtekkel való műveletek

#### 1. feladat
##### $ {1 \over 2} + {2 \over 3} =$ 

#### 2. feladat
##### $ {1 \over 2} - {3 \over 4} =$ 

#### 3. feladat
##### $ {7 \over 32} - {9 \over 64} =$ 

#### 4. feladat
##### $ {5 \over 12} - {7 \over 16} =$ 

#### 5. feladat
##### $ {1 \over 2} + {2 \over 3} =$ 

#### 5. feladat
##### $ {1 \over 2} + {2 \over 3} =$ 